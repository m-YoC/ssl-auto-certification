
## 関数の実行方法

```bash
curl -d '{}' http://localhost:9000/2015-03-31/functions/function/invocations | jq
```

